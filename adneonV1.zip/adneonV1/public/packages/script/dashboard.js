window.onload = function() {
	$('#dashboard').addClass('active');
}
