window.onload = function(){
	$('#telereports').addClass('active');
}