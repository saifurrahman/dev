 @extends('layouts.app') @section('content')
<section class="row m-b-md">
	<div class="col-sm-6">
		<h3 class="m-b-xs text-black">Dashboard</h3>
	</div>

</section>

{{HTML::script('packages/script/dashboard.js');}} @stop
