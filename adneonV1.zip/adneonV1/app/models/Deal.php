<?php
class Deal extends Eloquent{
	
	protected $table = 'deal_master';
	
}