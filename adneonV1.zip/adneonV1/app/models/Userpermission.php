<?php

class Userpermission extends Eloquent
{

    protected $table = 'user_permission';
}