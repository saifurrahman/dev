<?php

class Adschedule extends Eloquent
{

    protected $table = 'ad_schedule_master';
}