<?php
class Agency extends Eloquent{
	
	protected $table = 'agency_master';
 	
}