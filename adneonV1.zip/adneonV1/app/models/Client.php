<?php
class Client extends Eloquent{
	
	protected $table = 'client_master';
 	
}