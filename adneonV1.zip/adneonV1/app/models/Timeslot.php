<?php

class Timeslot extends Eloquent
{

    protected $table = 'timeslot_master';
}