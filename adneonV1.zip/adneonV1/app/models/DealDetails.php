<?php
class DealDetails extends Eloquent{

	protected $table = 'deal_details';

}
