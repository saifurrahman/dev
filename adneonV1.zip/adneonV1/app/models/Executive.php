<?php
class Executive extends Eloquent{
	
	protected $table = 'advetisement_executive';
	
	
}