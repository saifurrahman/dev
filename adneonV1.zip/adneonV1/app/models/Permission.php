<?php
class Permission extends Eloquent {
	protected $table = 'permission_type';
}