window.onload = function(){
	$('#news_update').addClass('active');
}
var token =  $("input[name=_token]").val();
