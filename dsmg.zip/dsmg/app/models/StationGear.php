<?php

class StationGear extends Eloquent
{

    protected $table = 'nfr_station_gear_master';
}
