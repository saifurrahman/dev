<?php

class MaintainanceLedger extends Eloquent
{

    protected $table = 'nfr_maintenance_schedule_ledger';
}
