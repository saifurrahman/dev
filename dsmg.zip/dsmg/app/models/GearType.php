<?php

class GearType extends Eloquent
{

    protected $table = 'nfr_gear_type_master';
}
