<?php

class District extends Eloquent
{

    protected $table = 'nfr_district_master';
}
