<?php

class ScheduleCode extends Eloquent
{

    protected $table = 'nfr_schedule_code_master';
}
