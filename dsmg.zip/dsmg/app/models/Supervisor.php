<?php

class Supervisor extends Eloquent
{

    protected $table = 'nfr_supervisors';
}
