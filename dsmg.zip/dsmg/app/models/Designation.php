<?php

class Designation extends Eloquent
{

    protected $table = 'nfr_supervisors_desig';
}
