<?php

class GearHistory extends Eloquent
{

    protected $table = 'nfr_gear_history';
}
