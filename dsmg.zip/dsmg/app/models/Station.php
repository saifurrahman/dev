<?php

class Station extends Eloquent
{

    protected $table = 'nfr_station_master';
}
