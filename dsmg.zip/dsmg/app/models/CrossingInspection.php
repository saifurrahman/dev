<?php

class CrossingInspection extends Eloquent
{

    protected $table = 'nfr_jp_crossing_inspection_ledger';
}
